package com.mycompany.frutas;

import java.util.Scanner;

public class FrutaTropical {
    
    public static String adivinarFruta() {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Intentare adivinar la fruta tropical que estas pensando");
        System.out.println("Responde con 's' para si y 'n' para no.");
        
        System.out.println("Tu fruta es de aspecto escamoso y es conocida como la 'fruta del dragon'?");
        char respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Pitaya";
        }
        
        System.out.println("Tu fruta tropical tiene forma de estrella y una textura similar a la pera?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Fruta estrella";
        }
        
        System.out.println("Tu fruta es de color cafe y es una vaina larga curveada?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Tamarindo";
        }
        
        System.out.println("Tu fruta tropical tiene una pulpa suave y cremosa, a menudo descrita como 'sabor a pina con platano'?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Chirimoya";
        }
        
        System.out.println("Tu fruta tropical tiene una piel exterior purpura o verde, con una pulpa dulce y jugosa en su interior?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Higo";
        }
        
        System.out.println("Tu fruta, tambien conocida como graviola, tiene una pulpa cremosa y un sabor dulce y acido?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Guanabana";
        }
        
        System.out.println("Tu fruta tiene una pulpa amarilla dulce y acida, y una cascara exterior aspera y espinosa?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Pina";
        }
        
        System.out.println("Tu fruta es como rojiza y contiene semillas rojas por dentro?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Granada";
        }
        
        System.out.println("Tu fruta tiene una cascara rojiza o amarilla cubierta de 'pelos' y una pulpa blanca y jugosa en su interior?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Rambutan";
        }
        
        System.out.println("Tu fruta es de color oscuro y pulpa dulce, conocida por su sabor similar al del chocolate?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Zapote negro";
        }
        
        System.out.println("Tu fruta tropical tiene una cascara naranja espinosa y una pulpa verde gelatinosa con semillas comestibles?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Kiwano";
        }
        
        System.out.println("Tu fruta, tambien conocida como 'carne de árbol', tiene una textura similar al pollo y se utiliza en platos salados y dulces?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Yaca";
        }
        
        System.out.println("Tu fruta tiene una apariencia unica, con una cascara roja y protuberancias blancas, y un sabor similar a la pina?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Pineberry";
        }
        
        System.out.println("Tu fruta tiene una pulpa anaranjada o rosada y es conocida por sus propiedades digestivas?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Papaya";
        }
        
        System.out.println("Tu fruta tambien conocida como fruta de la pasion, tiene una cascara arrugada y una pulpa con semillas jugosas?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Maracuya";
        }
        
        System.out.println("Tu fruta tiene una piel exterior colorida (como amarillo y rojizo) y una pulpa jugosa y dulce?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Mango";
        }
        
        System.out.println("Tu fruta, también conocida como naranjilla, tiene una pulpa jugosa y acida y se utiliza en jugos y postres?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Lulo";
        }
        
        System.out.println("Tu fruta tropical tiene una cascara dura y una pulpa gelatinosa con semillas comestibles?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Granadilla";
        }
        
        System.out.println("Tu fruta tiene una pulpa blanca y cremosa, con un sabor dulce y delicado?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Zapote blanco";
        }
        
        System.out.println("Tu fruta es variante del kiwi tiene una piel dorada y una pulpa dulce con jugo?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Kiwi Dorado";
        }
        
        System.out.println("Tu fruta tambien es conocida como higo chumbo, tiene una piel espinosa con una pulpa dulce y jugosa en su interior?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Tuna";
        }
        
        System.out.println("Tu fruta tambien es conocida como serpiente fruta, tiene una cascara de aspecto escamoso y una pulpa crujiente y dulce?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Salak";
        }
        
        System.out.println("Tu fruta es conocida como cereza de Barbados, tiene una piel roja o amarilla con una pulpa jugosa y acida?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Pitanga";
        }
        
        System.out.println("Tu fruta tiene una cascara dura y fibrosa que esconde una deliciosa pulpa blanca y jugosa?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
        return "Coco";
        }
    
        System.out.println("Tu fruta tiene una cascara rojiza y una pulpa translucida, siendo jugosa con una semilla grande en el centro?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
        return "Lychee";
        }
    
    // Si ninguna de las preguntas anteriores coincide, retornar "No se pudo determinar la fruta"
    return "No se pudo determinar la fruta.";
}

}