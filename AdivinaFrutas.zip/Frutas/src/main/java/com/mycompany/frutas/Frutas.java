package com.mycompany.frutas;

import java.util.Scanner;

public class Frutas {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            boolean repetir = true;
            
            while (repetir) {
                System.out.println("Hola. Quieres que trate de adivinar en que fruta piensas?");
                System.out.println("Responde con 's' para si y 'n' para no.");
                
                System.out.println("Tu fruta es tropical?");
                char respuesta = scanner.next().charAt(0);
                if (respuesta == 's') {
                    String frutaTropicalAdivinada = FrutaTropical.adivinarFruta();
                    System.out.println("La fruta que estas pensando es: " + frutaTropicalAdivinada + " ");
                } else {
                    System.out.println("Tu fruta es de clima templado?");
                    respuesta = scanner.next().charAt(0);
                    if (respuesta == 's') {
                        String frutaTempladoAdivinada = FrutaTemplado.adivinarFruta();
                        System.out.println("La fruta que estas pensando es: " + frutaTempladoAdivinada + " ");
                    } else {
                        System.out.println("Tu fruta es citrica?");
                        respuesta = scanner.next().charAt(0);
                        if (respuesta == 's') {
                            String frutaCitricaAdivinada = FrutaCitrica.adivinarFruta();
                            System.out.println("La fruta que estas pensando es: " + frutaCitricaAdivinada + " ");
                        } else {
                            System.out.println("Tu fruta es exotica?");
                            respuesta = scanner.next().charAt(0);
                            if (respuesta == 's') {
                                String frutaExoticaAdivinada = FrutaExotica.adivinarFruta();
                                System.out.println("La fruta que estas pensando es: " + frutaExoticaAdivinada + " ");
                            } else {
                                System.out.println("Tu fruta es de otra categoria no contemplada antes?");
                                respuesta = scanner.next().charAt(0);
                                if (respuesta == 's') {
                                    String frutasOtrasAdivinada = FrutasOtras.adivinarFruta();
                                    System.out.println("La fruta que estas pensando es: " + frutasOtrasAdivinada + " ");
                                } else {
                                    System.out.println("Indeterminable. Vuelve a correr el programa");
                                }
                            }
                        }
                    }
                }
                
                System.out.println("Quieres repetir el proceso? (s/n)");
                char repetirRespuesta = scanner.next().charAt(0);
                if (repetirRespuesta != 's') {
                    repetir = false;
                }
            }
        }
    }
}
