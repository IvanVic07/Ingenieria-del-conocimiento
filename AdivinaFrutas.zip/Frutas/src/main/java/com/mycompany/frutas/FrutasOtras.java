package com.mycompany.frutas;

import java.util.Scanner;

public class FrutasOtras {
    public static String adivinarFruta() {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Intentare adivinar la otra fruta que estas pensando");
        System.out.println("Responde con 's' para si y 'n' para no.");
        
        System.out.println("Tu fruta es verde y cremosa, originaria de Mexico, ampliamente utilizada en la cocina para hacer guacamole y se consume fresca en ensaladas y sandwiches?");
        char respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Aguacate";
        }
        
        System.out.println("Tu grupo de frutas son chicas y jugosas, como las fresas, arandanos y frambuesas, conocidas por su alto contenido de antioxidantes y se utilizan comunmente en postres, batidos y como complemento de cereales?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Bayas";
        }
        
        System.out.println("Tu fruta es de hueso similar al melocoton, originaria de Asia y se encuentra en variedades amarillas y rojas, con una pulpa dulce y jugosa?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Chavacanos";
        }
        
        System.out.println("Tu fruta es una variedad de platano, mas grande y con una piel mas gruesa que el platano comun, se utiliza principalmente en la cocina para hacer platos fritos o como ingrediente en guisos y sopas?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Platano macho";
        }
        
        System.out.println("Tu fruta es deshidratada, obtenida de la uva, es dulce y pegajosa, utilizada comunmente en la cocina para endulzar platos y hornear?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Pasa";
        }
        
        System.out.println("Tu fruta es grande y redonda, con una pulpa jugosa y dulce de color rojo o rosado, es refrescante y popular en el verano como postre o en ensaladas de frutas?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Sandia";
        }
        
        System.out.println("Tu fruta es redonda y dulce, con una pulpa jugosa y refrescante de color naranja o verde, es un elemento basico en las ensaladas de frutas y se consume fresca como postre o refrigerio?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Melon";
        }
        
        System.out.println("Tu fruta es de hueso, similar al albaricoque, originaria de Asia y se encuentra en variedades amarillas y rojas, con una pulpa jugosa y dulce?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Chabacano";
        }
        
        System.out.println("Tu fruta es una raiz tuberosa, crujiente y de sabor suave, utilizada en la cocina mexicana y es consumida fresca en ensaladas o como conjunto de otros platillos?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Jicama";
        }
        
        System.out.println("Tu fruta es de color marron oscuro y pulpa anaranjada o rojiza, tiene un sabor dulce y almibarado y se utiliza en batidos, helados y postres?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Mamey";
        }
        
        System.out.println("Tu fruta, originaria de America Central y del Sur, es conocida por ser el ingrediente principal en la produccion de chocolate y se cultiva principalmente por sus semillas?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Cacao";
        }
        
        // Si ninguna de las preguntas anteriores coincide, retornar "No se pudo determinar la fruta."
        return "No se pudo determinar la fruta.";
    }

}

