package com.mycompany.frutas;

import java.util.Scanner;

public class FrutaCitrica {
    public static String adivinarFruta() {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Intentare adivinar la fruta citrica que estas pensando");
        System.out.println("Responde con 's' para si y 'n' para no.");
        
        System.out.println("Tu fruta es chica y amarilla, conocida por su sabor acido y se utiliza comunmente para agregar sabor a platos (como los tacos) y bebidas?");
        char respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Limon";
        }
        
        System.out.println("Tu fruta es verde y redonda, similar al limon pero con un sabor mas suave, que se utiliza ampliamente en la cocina latinoamericana y en cocteles como la margarita?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Lima";
        }
        
        System.out.println("Tu fruta es grande y redonda, con una piel gruesa y amarilla, conocida por su sabor amargo y se come comunmente en rodajas o se utiliza en ensaladas?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Toronja";
        }
        
        System.out.println("Tu fruta es chica, de color naranja brillante y facil de pelar, es dulce y jugosa, y se come comunmente como refrigerio o postre?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Mandarina";
        }
        
        System.out.println("Tu fruta citrica es de color amarillo o verde claro, utilizada principalmente para extraer su aceite esencial, que se utiliza en perfumeria y aromaterapia?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Bergamota";
        }
        
        System.out.println("Tu fruta es grande y redonda, con una piel gruesa y un sabor dulce, ligeramente amargo, es similar a la toronja pero mas dulce y menos acida?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Pomelo";
        }
        
        // Si ninguna de las preguntas anteriores coincide, retornar "No se pudo determinar la fruta."
        return "No se pudo determinar la fruta.";
    }
    
}

