package com.mycompany.frutas;

import java.util.Scanner;

public class FrutaExotica {
    public static String adivinarFruta() {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Intentare adivinar la fruta exotica que estas pensando!");
        System.out.println("Responde con 's' para si y 'n' para no.");
        
        System.out.println("Tu fruta es chica y redonda, de color rojo intenso, conocida por su sabor agrio y se utiliza a menudo en la preparacion de mermeladas, jaleas, postres y raspados?");
        char respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Grosella";
        }
        
        System.out.println("Tu fruta es de forma redondeada y color amarillo o rojo, originaria de Mexico y se utiliza comunmente en la elaboracion de dulces y conservas, asi como en bebidas como el ponche?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Tejocote";
        }
        
        System.out.println("Tu fruta es de origen asiatico, tambien conocida como 'pera asiatica', tiene una textura crujiente similar a la manzana con un sabor dulce y refrescante?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Nashi";
        }
        
        System.out.println("Tu fruta es de forma redondeada y color rojo o amarillo, ampliamente utilizada en la cocina mexicana para preparar salsas, guisos, y ensaladas, siendo un ingrediente basico en platos como el pico de gallo y la salsa de tomate?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Jitomate";
        }
        
        System.out.println("Tu fruta es chica y redonda, de color amarillo anaranjado y con una cascara que envuelve una pulpa jugosa y dulce, originaria de America del Sur y se consume fresca o en postres y ensaladas?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Uchuva";
        }
        
        // Si ninguna de las preguntas anteriores coincide, retornar "No se pudo determinar la fruta."
        return "No se pudo determinar la fruta.";
    }
}
