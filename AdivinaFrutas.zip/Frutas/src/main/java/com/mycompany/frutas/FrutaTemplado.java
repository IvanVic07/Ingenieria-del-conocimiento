package com.mycompany.frutas;

import java.util.Scanner;

public class FrutaTemplado {
    public static String adivinarFruta() {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Intentare adivinar la fruta de clima templado que estas pensando!");
        System.out.println("Responde con 's' para si y 'n' para no.");
        
        System.out.println("Tu fruta es asociada con la historia de Newton y la ley de la gravedad?");
        char respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Manzana";
        }
        
        System.out.println("Tu fruta tiene forma alargada con una base ancha y una textura jugosa y suave; de color verde?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Pera";
        }
        
        System.out.println("Tu fruta es chica, amarilla y redondeada; conocida por su sabor dulce y su aroma distintivo?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Nispero";
        }
        
        System.out.println("Tu fruta es chica, similar a la cereza pero mas oscura y con sabor mas intenso, siendo popular en America Latina?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Capulin";
        }
        
        System.out.println("Tu fruta es roja y chica, tiene un hueso en el centro y es comúnmente asociada con postres y pasteles?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Cereza";
        }
        
        System.out.println("Tu fruta es de color morado o amarillo, tiene un sabor dulce, es jugosa y a menudo se utiliza en mermeladas y conservas?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Ciruelas";
        }
        
        System.out.println("Tu fruta es redondeada y con un hueso en su interior, tiene una piel aterciopelada y una pulpa jugosa y dulce?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Durazno";
        }
        
        System.out.println("Tu fruta es chica y redonda, crece en racimos y se utiliza para hacer vino y pasas?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Uva";
        }
        
        System.out.println("Tu fruta es similar al durazno pero con piel lisa y brillante, es conocida por su sabor dulce y jugoso?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Nectarina";
        }
        
        System.out.println("Tu fruta es morada o negra, similar a la frambuesa pero mas grande y menos firme, es popular en la reposteria?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Zarzamora";
        }
        
        System.out.println("Tu fruta es chica y roja, con un sabor dulce y ligeramente acido, crece en arbustos espinosos?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Frambuesa";
        }
        
        System.out.println("Tu fruta es seca y dulce, que crece en palmeras, comunmente consumida como un bocadillo energetico o se utiliza en la cocina para endulzar platos?");
        respuesta = scanner.next().charAt(0);
        if (respuesta == 's') {
            return "Datil";
        }
        
        // Si ninguna de las preguntas anteriores coincide, retornar "No se pudo determinar la fruta."
        return "No se pudo determinar la fruta.";
    }

}
